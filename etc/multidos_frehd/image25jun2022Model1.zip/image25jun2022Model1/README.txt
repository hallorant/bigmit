Notes:
o Should be a floppy boot FreHD for MULTIDOS for the Model 1.
o I'm unable to get this to work, my real Model 1 FreHD not working.
  I'm awaiting a real Model 1 FreHD from Ian, my patched up setup with the
  Benson box doesn't work, yet (still trying with known okay floppy-boot OSs).
o with trs80gp I used
    trs80gp -m1 -d0 M1MULTIDOSFreHD.hfe -h0 hard4-0 -frehd
  which starts up ULTRADOS but I just get the floppy disk.

-------------------
-- Vernon's Note --
-------------------

Attached is the 'boot' floppy for the Model I FreHD that I put on the Google
Drive (shared with you).

1. Copy the drive to an SD card.

2. The .HFE file is a single-density floppy (I don't know what you have) to
load track 0, sector 0 then jump to 4200H (as a Model I ROM would). i.e., if
you have a floppy drive zero attached to you Model I, then create a floppy
using the .HFE file and 

Regards,
Vernon
