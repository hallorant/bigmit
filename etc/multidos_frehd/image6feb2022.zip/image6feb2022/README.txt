--------------------------
MultiDOS FreHD Image v6.10
by Vernon Hester (OS & HD image)
   Tim Halloran (FreHD utils)
--------------------------
6 Feb 2022

This is a test image of MultiDOS 6.1 for the Model 4 for FreHD.
This is Vernon's release with the following FreHD utilities added:
* VHDUTL/CMD
* IMPORT2/CMD
* EXPORT2/CMD
These have been tested on a real Model 4 (less so on trs80gp).

-- Use on a real Model 4 --

1. Place "hard4-0" at the root of your FreHD SD card
2. Use "multidos_boot_floppy.hfe" as your boot floppy. If you don't have a floppy
   emulator as your disk 0 you'll need to create a floppy from this image
3. Boot to MuliDOS, you may now remove boot floppy (not needed after boot)

-- Use on trs80gp --

I texted on http://48k.ca/trs80gp.html version 2.4.5, just use the command line:

$ trs80gp -m4 -d0 multidos_boot_floppy.hfe -h0 hard4-0 -frehd

